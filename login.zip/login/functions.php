<?php

function check_login($con)
{

    // Check for if the user is logged in or not  


    // Redirecting to to login using  Header function 
    header("Location:login.php");
}
